//
// AppSettings.swift
// MedicalRecorder
//
// アプリケーション設定の管理
// APIキー、トークン、リポジトリ情報をUserDefaultsで保存
//

import Foundation
import Combine

class AppSettings: ObservableObject {
    // シングルトンインスタンス
    static let shared = AppSettings()
    
    private let defaults = UserDefaults.standard
    
    // API プロバイダー選択
    @Published var transcriptionProvider: TranscriptionProvider {
        didSet {
            defaults.set(transcriptionProvider.rawValue, forKey: "transcriptionProvider")
        }
    }
    
    // さくらのAI API設定
    @Published var sakuraTokenID: String {
        didSet { defaults.set(sakuraTokenID, forKey: "sakuraTokenID") }
    }
    
    @Published var sakuraSecret: String {
        didSet { defaults.set(sakuraSecret, forKey: "sakuraSecret") }
    }
    
    // Aqua Voice API設定
    @Published var aquaVoiceAPIKey: String {
        didSet { defaults.set(aquaVoiceAPIKey, forKey: "aquaVoiceAPIKey") }
    }
    
    // AmiVoice API設定
    @Published var amiVoiceAPIKey: String {
        didSet { defaults.set(amiVoiceAPIKey, forKey: "amiVoiceAPIKey") }
    }
    
    @Published var amiVoiceEngine: String {
        didSet { defaults.set(amiVoiceEngine, forKey: "amiVoiceEngine") }
    }
    
    // GitHub設定
    @Published var githubToken: String {
        didSet { defaults.set(githubToken, forKey: "githubToken") }
    }
    
    @Published var githubOwner: String {
        didSet { defaults.set(githubOwner, forKey: "githubOwner") }
    }
    
    @Published var githubRepo: String {
        didSet { defaults.set(githubRepo, forKey: "githubRepo") }
    }
    
    @Published var githubBranch: String {
        didSet { defaults.set(githubBranch, forKey: "githubBranch") }
    }
    
    @Published var githubPath: String {
        didSet { defaults.set(githubPath, forKey: "githubPath") }
    }
    
    // 保存オプション
    @Published var saveRawTranscription: Bool {
        didSet { defaults.set(saveRawTranscription, forKey: "saveRawTranscription") }
    }
    
    @Published var saveAudioFile: Bool {
        didSet { defaults.set(saveAudioFile, forKey: "saveAudioFile") }
    }
    
    // 初期化
    private init() {
        // API プロバイダー選択（デフォルト: さくらのAI）
        if let providerString = defaults.string(forKey: "transcriptionProvider"),
           let provider = TranscriptionProvider(rawValue: providerString) {
            self.transcriptionProvider = provider
        } else {
            self.transcriptionProvider = .sakura
        }
        
        // さくらのAI (デフォルト値 - 初回起動時)
        self.sakuraTokenID = defaults.string(forKey: "sakuraTokenID") ?? ""
        self.sakuraSecret = defaults.string(forKey: "sakuraSecret") ?? ""
        
        // Aqua Voice
        self.aquaVoiceAPIKey = defaults.string(forKey: "aquaVoiceAPIKey") ?? ""
        
        // AmiVoice
        self.amiVoiceAPIKey = defaults.string(forKey: "amiVoiceAPIKey") ?? ""
        self.amiVoiceEngine = defaults.string(forKey: "amiVoiceEngine") ?? "-a-general"
        
        // GitHub (デフォルト値)
        self.githubToken = defaults.string(forKey: "githubToken") ?? "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"
        self.githubOwner = defaults.string(forKey: "githubOwner") ?? "katu09161004"
        self.githubRepo = defaults.string(forKey: "githubRepo") ?? "Obsidian"
        self.githubBranch = defaults.string(forKey: "githubBranch") ?? "main"
        self.githubPath = defaults.string(forKey: "githubPath") ?? "recordings"
        
        // 保存オプション
        self.saveRawTranscription = defaults.bool(forKey: "saveRawTranscription") // デフォルト false
        self.saveAudioFile = defaults.bool(forKey: "saveAudioFile") // デフォルト false
        
        // 初回起動時の設定
        if !defaults.bool(forKey: "hasLaunchedBefore") {
            self.saveRawTranscription = true // 初回はON
            defaults.set(true, forKey: "hasLaunchedBefore")
        }
    }
    
    // 設定が完了しているか確認
    var isConfigured: Bool {
        let hasGitHub = !githubToken.isEmpty && !githubOwner.isEmpty && !githubRepo.isEmpty
        
        // LLM処理のため、どのプロバイダーでもさくらのAI設定が必要
        let hasSakuraLLM = !sakuraTokenID.isEmpty && !sakuraSecret.isEmpty
        
        let result: Bool
        
        switch transcriptionProvider {
        case .sakura:
            result = hasSakuraLLM && hasGitHub
            print("📝 設定チェック (さくらのAI)")
            print("  - さくらLLM: \(hasSakuraLLM)")
            print("  - GitHub: \(hasGitHub)")
            print("  - 結果: \(result)")
        case .aquaVoice:
            result = !aquaVoiceAPIKey.isEmpty && hasSakuraLLM && hasGitHub
            print("📝 設定チェック (Aqua Voice)")
            print("  - AquaVoice APIキー: \(!aquaVoiceAPIKey.isEmpty)")
            print("  - さくらLLM: \(hasSakuraLLM)")
            print("  - GitHub: \(hasGitHub)")
            print("  - 結果: \(result)")
        case .amiVoice:
            result = !amiVoiceAPIKey.isEmpty && hasSakuraLLM && hasGitHub
            print("📝 設定チェック (AmiVoice)")
            print("  - AmiVoice APIキー: \(!amiVoiceAPIKey.isEmpty)")
            print("  - さくらLLM: \(hasSakuraLLM)")
            print("  - GitHub: \(hasGitHub)")
            print("  - 結果: \(result)")
        }
        
        return result
    }
    
    // 設定をリセット
    func resetToDefaults() {
        transcriptionProvider = .sakura
        sakuraTokenID = "2d25ae00-57a9-43e7-a08d-84aa230fa577"
        sakuraSecret = "KMFTq/MVZydsmTa0T3zAwrK+IcqSt9dq+pBjvcZx"
        aquaVoiceAPIKey = ""
        amiVoiceAPIKey = ""
        amiVoiceEngine = "-a-general"
        githubToken = "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"
        githubOwner = "katu09161004"
        githubRepo = "Obsidian"
        githubBranch = "main"
        githubPath = "recordings"
        saveRawTranscription = true
        saveAudioFile = false
    }
}

