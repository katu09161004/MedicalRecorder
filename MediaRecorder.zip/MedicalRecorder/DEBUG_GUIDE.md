# デバッグガイド：Aqua Voice で結果が表示されない問題

## 🔍 Xcodeコンソールの確認手順

### 1. コンソールを表示
```
Command + Shift + Y
```

### 2. コンソールのフィルターを確認
コンソール下部の検索バーの左側に「All」と表示されているか確認してください。
もし「Errors and Warnings」などになっていたら、「All」に変更してください。

### 3. コンソールをクリア
コンソール右側のゴミ箱アイコンをクリックして、ログをクリアします。

### 4. アプリを再起動
Xcodeで Stop して、もう一度 Run します。

### 5. 録音テスト
- 録音開始をタップ
- 3秒程度話す
- 録音停止をタップ

### 6. コンソールで探すべきキーワード
以下のいずれかが表示されているはずです：

```
🎬 toggleRecording
🛑 録音停止処理開始
✅ 録音ファイル保存
🔍 設定チェック開始
【設定未完了】 ← これが表示されたら設定が不足
🎤 音声処理開始
🔧 APIプロバイダー
🔀 プロバイダー選択
🎯 Aqua Voice API 呼び出し開始
🚀 AquaVoiceAPI.transcribeAudio 開始
```

## 🚨 よくある問題

### 問題1: コンソールに何も表示されない

**原因**: 
- デバッグビルドではなくReleaseビルドになっている
- コンソールのフィルターが設定されている
- print文が実際には実行されていない

**対処法**:
1. Product > Scheme > Edit Scheme
2. Run > Info タブ
3. Build Configuration が「Debug」になっているか確認

### 問題2: 「設定未完了」アラートが出る

**必要な設定（Aqua Voice使用時）**:
- ✅ Aqua Voice APIキー（`ava_` で始まる）
- ✅ さくらのAI トークンID
- ✅ さくらのAI シークレットキー
- ✅ GitHubトークン
- ✅ GitHubオーナー
- ✅ GitHubリポジトリ

**確認方法**:
メイン画面のヘッダーに以下が表示されるか：
- 「Aqua Voice (Avalon)」
- 「設定完了」（緑色）

### 問題3: 「さくらのAI処理中」のまま止まる

これは以下の可能性があります：
1. Aqua Voice APIに到達していない
2. APIからエラーが返ってきている
3. ネットワークエラー

**確認方法**:
コンソールで以下を探す：
```
🚀 AquaVoiceAPI.transcribeAudio 開始
```

もしこれが表示されていない場合：
→ プロバイダー選択で「さくらのAI」が選ばれている可能性

もしこれが表示されている場合：
→ その後の `📥 Aqua Voice API レスポンス:` を確認

## 📱 設定画面のスクリーンショット確認

以下の情報を確認してください：

### 文字起こしAPI
- [ ] 「Aqua Voice (Avalon)」が選択されている

### Aqua Voice API
- [ ] APIキーが入力されている（`ava_` で始まる）

### さくらのAI API（LLM処理用）
- [ ] トークンIDが入力されている
- [ ] シークレットキーが入力されている

### GitHub連携
- [ ] GitHubトークンが入力されている
- [ ] オーナー名が入力されている
- [ ] リポジトリ名が入力されている

## 🔧 強制ログ出力テスト

設定を確認するために、`MainView.swift` の `body` に以下を追加：

```swift
.onAppear {
    print("=" * 50)
    print("🔧 設定状態:")
    print("  プロバイダー: \(AppSettings.shared.transcriptionProvider.displayName)")
    print("  Aqua APIキー: \(AppSettings.shared.aquaVoiceAPIKey.prefix(10))...")
    print("  さくらToken: \(AppSettings.shared.sakuraTokenID.isEmpty ? "未設定" : "設定済み")")
    print("  さくらSecret: \(AppSettings.shared.sakuraSecret.isEmpty ? "未設定" : "設定済み")")
    print("  GitHub: \(AppSettings.shared.githubToken.isEmpty ? "未設定" : "設定済み")")
    print("  isConfigured: \(AppSettings.shared.isConfigured)")
    print("=" * 50)
    setupWatchConnectivity()
}
```

これをアプリ起動時に実行して、設定が読み込まれているか確認してください。

## 💡 最終手段：プロバイダーを強制指定

もし設定が正しいのに動かない場合、一時的にコードでプロバイダーを強制指定してテスト：

`NetworkManager.swift` の `transcribeAudio` を以下のように変更：

```swift
private func transcribeAudio(audioURL: URL, completion: @escaping (Bool, String) -> Void) {
    print("🔀 プロバイダー選択: \(settings.transcriptionProvider.displayName)")
    
    // 強制的に Aqua Voice を使用（デバッグ用）
    print("⚠️ 強制的に Aqua Voice を使用")
    transcribeWithAquaVoice(audioURL: audioURL, completion: completion)
    return
    
    // 以下は実行されない
    switch settings.transcriptionProvider {
    case .sakura:
        print("➡️ さくらのAI を使用")
        transcribeWithSakura(audioURL: audioURL, completion: completion)
    case .aquaVoice:
        print("➡️ Aqua Voice を使用")
        transcribeWithAquaVoice(audioURL: audioURL, completion: completion)
    }
}
```

これでさくらのAIの設定に関係なく、必ずAqua Voiceが呼ばれるようになります。
