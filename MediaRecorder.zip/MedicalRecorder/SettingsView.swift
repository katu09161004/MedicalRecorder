//
// SettingsView.swift
// MedicalRecorder
//
// アプリケーション設定画面
//

import SwiftUI

struct SettingsView: View {
    @ObservedObject var settings = AppSettings.shared
    @Environment(\.dismiss) var dismiss
    
    @State private var showingSaveAlert = false
    @State private var showingResetAlert = false
    
    var body: some View {
        NavigationView {
            Form {
                // API プロバイダー選択
                Section(header: Text("文字起こしAPI")) {
                    Picker("APIプロバイダー", selection: $settings.transcriptionProvider) {
                        ForEach(TranscriptionProvider.allCases) { provider in
                            HStack {
                                Image(systemName: provider.icon)
                                Text(provider.displayName)
                            }
                            .tag(provider)
                        }
                    }
                    .pickerStyle(.menu)
                    
                    Text(settings.transcriptionProvider.description)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                // さくらのAI API設定
                if settings.transcriptionProvider == .sakura {
                    Section(header: Text("さくらのAI API")) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("トークンID")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            TextField("例: 2d25ae00-57a9-...", text: $settings.sakuraTokenID)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("シークレットキー")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            SecureField("例: KMFTq/MVZyd...", text: $settings.sakuraSecret)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        Link(destination: URL(string: "https://ai.sakura.ad.jp/")!) {
                            HStack {
                                Image(systemName: "link.circle.fill")
                                Text("さくらのAI ダッシュボード")
                                Spacer()
                                Image(systemName: "arrow.up.right.square")
                            }
                        }
                    }
                }
                
                // Aqua Voice API設定
                if settings.transcriptionProvider == .aquaVoice {
                    Section(header: Text("Aqua Voice API")) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("APIキー")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            SecureField("Aqua Voice API Key", text: $settings.aquaVoiceAPIKey)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        Link(destination: URL(string: "https://aqua-voice.com/")!) {
                            HStack {
                                Image(systemName: "link.circle.fill")
                                Text("Aqua Voice ダッシュボード")
                                Spacer()
                                Image(systemName: "arrow.up.right.square")
                            }
                        }
                    }
                    
                    // Aqua Voice使用時もLLM処理のためさくらのAI設定が必要
                    Section(header: Text("さくらのAI API（LLM処理用）")) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("⚠️ AI要約処理にさくらのAIを使用します")
                                .font(.caption)
                                .foregroundColor(.orange)
                            Text("文字起こしはAqua Voice、要約・箇条書きはさくらのAIで行います")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("トークンID")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            TextField("例: 2d25ae00-57a9-...", text: $settings.sakuraTokenID)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("シークレットキー")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            SecureField("例: KMFTq/MVZyd...", text: $settings.sakuraSecret)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                    }
                }
                
                // AmiVoice API設定
                if settings.transcriptionProvider == .amiVoice {
                    Section(header: Text("AmiVoice Cloud API")) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("APIキー")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            SecureField("AmiVoice API Key", text: $settings.amiVoiceAPIKey)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("エンジン")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Picker("エンジン", selection: $settings.amiVoiceEngine) {
                                Text("-a-general（汎用）").tag("-a-general")
                                Text("-a-medical（医療）").tag("-a-medical")
                                Text("-a-business（ビジネス）").tag("-a-business")
                                Text("-a-call（コールセンター）").tag("-a-call")
                            }
                            .pickerStyle(.menu)
                        }
                        
                        Link(destination: URL(string: "https://acp.amivoice.com/")!) {
                            HStack {
                                Image(systemName: "link.circle.fill")
                                Text("AmiVoice Cloud ダッシュボード")
                                Spacer()
                                Image(systemName: "arrow.up.right.square")
                            }
                        }
                    }
                    
                    // AmiVoice使用時もLLM処理のためさくらのAI設定が必要
                    Section(header: Text("さくらのAI API（LLM処理用）")) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("⚠️ AI要約処理にさくらのAIを使用します")
                                .font(.caption)
                                .foregroundColor(.orange)
                            Text("文字起こしはAmiVoice、要約・箇条書きはさくらのAIで行います")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("トークンID")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            TextField("例: 2d25ae00-57a9-...", text: $settings.sakuraTokenID)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("シークレットキー")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            SecureField("例: KMFTq/MVZyd...", text: $settings.sakuraSecret)
                                .textContentType(.password)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .font(.system(.body, design: .monospaced))
                        }
                    }
                }
                
                // GitHub設定
                Section(header: Text("GitHub連携")) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Personal Access Token")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        SecureField("ghp_xxxxxxxxxxxx", text: $settings.githubToken)
                            .textContentType(.password)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .font(.system(.body, design: .monospaced))
                    }
                    
                    TextField("オーナー名", text: $settings.githubOwner)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    TextField("リポジトリ名", text: $settings.githubRepo)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    TextField("ブランチ", text: $settings.githubBranch)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    TextField("保存パス", text: $settings.githubPath)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    Link(destination: URL(string: "https://github.com/settings/tokens")!) {
                        HStack {
                            Image(systemName: "key.fill")
                            Text("GitHub トークン作成")
                            Spacer()
                            Image(systemName: "arrow.up.right.square")
                        }
                    }
                }
                
                // 保存オプション
                Section(header: Text("保存設定")) {
                    Toggle(isOn: $settings.saveRawTranscription) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("文字起こし生データを保存")
                                .font(.body)
                            Text("Whisperの出力そのまま (処理前)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Toggle(isOn: $settings.saveAudioFile) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("音声ファイルを保存")
                                .font(.body)
                            Text("録音したm4aファイル (.m4a)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // 情報・アクション
                Section {
                    Button(action: { showingSaveAlert = true }) {
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                            Text("設定を保存")
                            Spacer()
                        }
                    }
                    
                    Button(action: { showingResetAlert = true }) {
                        HStack {
                            Image(systemName: "arrow.counterclockwise.circle.fill")
                                .foregroundColor(.orange)
                            Text("設定をリセット")
                            Spacer()
                        }
                    }
                }
                
                // ステータス表示
                Section(header: Text("ステータス")) {
                    HStack {
                        Text("設定状態")
                        Spacer()
                        if settings.isConfigured {
                            Label("完了", systemImage: "checkmark.circle.fill")
                                .foregroundColor(.green)
                        } else {
                            Label("未完了", systemImage: "exclamationmark.triangle.fill")
                                .foregroundColor(.orange)
                        }
                    }
                }
            }
            .navigationTitle("設定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完了") {
                        dismiss()
                    }
                }
            }
            .alert("設定を保存しました", isPresented: $showingSaveAlert) {
                Button("OK") { }
            }
            .alert("設定をリセットしますか?", isPresented: $showingResetAlert) {
                Button("キャンセル", role: .cancel) { }
                Button("リセット", role: .destructive) {
                    settings.resetToDefaults()
                }
            }
        }
    }
}

